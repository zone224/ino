let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Telkomsel [6282133629784]
│ • Gopay [6282133629784]
╰────
╭─「 Hubungi 」
│ > Ingin donasi? Wa.me/82133629784
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
